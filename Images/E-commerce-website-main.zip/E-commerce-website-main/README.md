# E-Commerce Website Frontend
This is a frontend e-commerce website built using HTML, CSS, and JavaScript. Users can see the products, view the product according to category (like men, women, etc). It’s a fully responsive design to ensure a smooth user experience on both desktop and mobile devices.
## Technologies Used
- HTML
- CSS
- JavaScript 

## Project Demo
click here https://dilipbist.github.io/E-commerce-website/
